﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardAssignment
{
    class Player
    {
        public string Name {get; set;}
        
        public List<Card> Hand = new List<Card>();

        public Player(string name)
        {
            Name = name;
        }

        public Card Draw(Deck deck)
        {
            Card card = deck.Deal();

            addToHand(card);

            return card;
        }

        public Card Discard(int index)
        {
            Card card = Hand[index];

            if(card == null)
            {
                return null;
            }

            removeFromHand(index);
            
            return card;
        }

        public void PrintHand()
        {
            Console.WriteLine("(Player)Here is the Hand(" + Hand.Count + "): ");
            foreach(Card c in Hand)
            {
                c.Print();
            }
        }

        private void addToHand(Card card)
        {
            Hand.Add(card);
        }

        private void removeFromHand(int index)
        {
            Hand.RemoveAt(index);
        }
    }
}

/*
Give the Player class a name property.

Give the Player a hand property that is a List of type Card.

Give the Player a draw method of which draws a card from a deck,
adds it to the player's hand and returns the Card.
Note this method will require reference to a deck object

Check your work by drawing three cards and printing the player's hand
to the console. 

Give the Player a discard method which discards the Card at the
specified index from the player's hand and returns this Card
or null if the index does not exist.

Check your work printing the Player's hand after the discard method was called.
 */