﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardAssignment
{
    class Card
    {

        public static string[] Names = new string[]
        {
            "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"
        };

        public static string[] Suits = new string[]
        {
            "Clubs", "Spades", "Hearts", "Daimonds"
        };

        public static int[] Values = new int[]
        {
            1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ,11, 12, 13
        };

        public string Name { get; set; }

        public string Suit { get; set; }
        
        public int Value { get; set; }

        public Card(){}

        public Card(string name, string suit, int value, bool debug = false)
        {
            Name = name;
            Suit = suit;
            Value = value;

            if(debug)
            {
                Print();
            }
            
        }

        public void Print()
        {
            Console.WriteLine("(Card)Name: " + Name + ", Suit: " + Suit + ", Value: " + Value + ".");
        }
        
        public string PrintAsString()
        {
            string card = ("(Card)Name: " + Name + ", Suit: " + Suit + ", Value: " + Value + ".");
            
            return card;
        }
    }
}

/*Give the Card class a property called "name" which will hold the value of the card ex. (Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack, Queen, King). 
 * This "name" property should be a string.
 * 
Give the Card a property called "suit" which will hold the suit of the card (Clubs, Spades, Hearts, Diamonds).

Give the Card a property called "val" which will hold the numerical value of the card (1-13) as integers.

Add a Print method to your card class that prints out the name, value and suit of each card.

Check your work! Instantiate a card in the Program.cs file and make sure the name, value and suit prints in the console. 
*/