﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace CardAssignment
{
    class Deck
    {
        public List<Card> Cards = new List<Card>();

        public Deck()
        {
            Reset();
        }

        public Card Deal(bool debug = false)
        {
            Card card = Cards[0];
            
            Console.WriteLine("(Deck)Removing: " + Cards[0].PrintAsString() + " from the deck...");
            
            Cards.RemoveAt(0);

            if(debug)
            {
                PrintCount();
            }
           
            return card;
        }

        public void Reset(bool debug = false)
        {
            Cards.Clear();

            for (int h = 0; h < 4; ++h)
            {
                for (int i = 0; i < 13; ++i)
                {
                    Card newCard = new Card(Card.Names[i], Card.Suits[h], Card.Values[i]);
                    Cards.Add(newCard);
                }
            }

            if(debug)
            {
                Console.WriteLine();
                Console.WriteLine("Printing Cards:");
                Console.WriteLine();
                PrintAllCards();
                Console.WriteLine();
                PrintCount();
                Console.WriteLine();
            }
            
        }

        public void Shuffle(bool debug = false)
        {
            Random rand = new Random();

            List<Card> tempCards = new List<Card>();

            var randomized = Cards.OrderBy(item => rand.Next());
           
            foreach (var c in randomized)
            {
               tempCards.Add(c);
            }

            Cards = tempCards;

             if(debug)
            {
                PrintCount();
                PrintAllCards();
            }
        }

        public void PrintCount()
        {
            Console.WriteLine("Cards.Count: " + Cards.Count.ToString());
        }

        public void PrintAllCards()
        {
            foreach(Card c in Cards)
            {
                c.Print();
            }
           
        }
    }
}

/*
Give the Deck class a property called "cards" which is a list of Card objects.

When initializing the deck, make sure that it has a list of 52 unique cards
as its "cards" property. While it is entirely possible to type .Add and
instantiate each card separately, there is a much more efficient way to do this!
Think about the pattern of a deck. There are 4 suits and 13 values for each suit.
Don't worry about the name of the card (eg: Ace, Jack, Queen) just yet.
You can add the name after you work out the pattern. Start by figuring out
how you would make 4 cards of each suit. Then think about how you would
make 13 cards for each of those 4 suits each with their own unique value
from 1 to 13. We are doing a certain set of actions repeatedly. How do we
do something repeatedly in code? Check your work! Instantiate a Deck so
each card prints in the console. 

Create methods in "Deck"

Give the Deck a deal method that selects the "top-most" card,
removes it from the list of cards, and returns the Card. 

Give the Deck a reset method that resets the cards property
to contain the original 52 cards. 

Give the Deck a shuffle method that randomly reorders the deck's cards. 

Check your work by printing either your entire deck
and/or the deck count after each method is called.
 */