﻿using System;

namespace CardAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Making Cards!");

            Deck deck = new Deck();

            deck.Shuffle();

            Player player = new Player("K1udg3");

            Console.WriteLine();
           
           for(int i = 0; i < 3; ++i)
           {
                Console.WriteLine("Draw #" + i);
                
                player.Draw(deck);

           }
            
            Console.WriteLine();

            player.PrintHand();

            Console.WriteLine();

            int index = 0;

            Console.WriteLine("Discarding index(" + index + "): " + player.Discard(0));
           
            Console.WriteLine();
           
            player.PrintHand();

            //deck.Deal();

            //deck.Shuffle();       
        }
    }
}